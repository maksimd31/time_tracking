from django.apps import AppConfig


class TimeTrackingMainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_tracking_main'
