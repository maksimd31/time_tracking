github actions
name: Django Migrations and Requirements Update

on:
  push:
    branches:
      - main  
#   push:
#     branches: [ "main" ]
#   pull_request:
#     branches: [ "main" ]

jobs:
  migrate:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v2

      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.12'  

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install -r requirements.txt  # Ensure this file is in the root

      - name: Make migrations
        run: |
          python manage.py makemigrations
        env:
          SECRET_KEY: ${{ secrets.SECRET_KEY }}  

      - name: Run migrations
        run: |
          python manage.py migrate
        env:
          SECRET_KEY: ${{ secrets.SECRET_KEY }} 

      - name: Update requirements.txt
        run: |
          pip freeze > requirements.txt






from time_tracking_main.models import TimeInterval  
python manage.py shell

from django.db import models
from django.contrib.auth.models import User
from time_tracking_main.models import TimeInterval
from datetime import datetime, timedelta

user = User.objects.get(username='admin')  

TimeInterval.objects.create(
    user=user, 
    start_time= datetime.now(),  
    end_time= datetime.now()+timedelta(hours=1), 
)



функция send_mail() это удобный и мощный инструмент Django для отправки электронных писем. С ее помощью можно реализовывать различные функции: отправку уведомлений, подтверждение регистрации, рассылку новостей и другие.

 Функция send_mail() принимает следующие аргументы:

send_mail(
    subject,  # Заголовок письма (строка)
    message,  # Тело письма (строка)
    from_email, # Адрес отправителя (строка)
    recipient_list, # Список адресов получателей (список строк)
    fail_silently=False,  # Флаг для подавления ошибок (логическое значение, по умолчанию False)
    auth_user=None,  # Пользователь для аутентификации (строка, по умолчанию None)
    auth_password=None, # Пароль для аутентификации (строка, по умолчанию None)
    connection=None,  # Пользовательское соединение (объект, по умолчанию None)
    html_message=None # Тело письма в формате HTML (строка, по умолчанию None)
)


from django.core.mail import send_mail
send_mail('Django mail',
          'This e-mail was sent with Django.',
          'maksimdis31@gmail.com',
          ['timemanagerpet@gmail.com'],
          fail_silently=False)
